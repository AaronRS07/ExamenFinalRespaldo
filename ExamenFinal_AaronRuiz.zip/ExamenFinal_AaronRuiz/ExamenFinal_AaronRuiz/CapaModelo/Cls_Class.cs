﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace ExamenFinal_AaronRuiz.CapaModelo
{
    public class Cls_Class
    {
        public int id { get; set; }
        public string nombre { get; set; }
    }
}